import axios from "axios";
import React, { useEffect, useState } from "react";

function FavoriteItem({ book }) {
  const [imgStr, setImgStr] = useState("");
  useEffect(() => {
    axios
      .get(
        "http://localhost:8098/file/getBookCoverList?bookIdList=" + book.book_id
      )
      .then((res) => {
        console.log(res.data.data[0]);
        setImgStr(res.data.data[0].book_cover);
      })
      .catch((err) => console.log(err));
  }, [book]);
  return (
    <div className="favorite-item">
      <img src={"data:image/png;base64," + imgStr} alt="Image" />
      <p>{book.book_name}</p>
    </div>
  );
}

export default FavoriteItem;

import React, { useEffect, useState } from "react";
import "../styles/Favorite.scss";
import axios from "axios";
import { useAuth } from "../auth/AuthProvider";
import FavoriteItem from "../ui/FavoriteItem";

const FavoritePage = () => {
  const [favBook, setFavBook] = useState([]);
  const { token } = useAuth();
  useEffect(() => {
    axios
      .get("http://localhost:8098/user/bookmark", {
        headers: { Authorization: "Bearer " + token },
      })
      .then((res) => {
        console.log("bookmark", res.data);
        setFavBook(res.data);
      })
      .catch((res) => console.log(res));
  }, []);
  return (
    <div className="favorite-ctn">
      <h2>Yêu thích</h2>
      <div className="book-ctn">
        {favBook.map((book) => (
          <FavoriteItem book={book} />
        ))}
      </div>
    </div>
  );
};

export default FavoritePage;

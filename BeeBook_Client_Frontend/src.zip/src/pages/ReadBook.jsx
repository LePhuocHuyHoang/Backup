import { useEffect, useRef, useState } from "react";
import RateBook from "../ui/RateBook";
import "../styles/ReadBook.scss";
import Tooltip from "@mui/material/Tooltip";
import axios from "axios";
import { Comment } from "react-loader-spinner";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";
import { useAuth } from "../auth/AuthProvider";
import InfiniteScroll from "react-infinite-scroll-component";
const ReadBook = () => {
  const [showHeaderFooter, setShowHeaderFooter] = useState(true);
  const [imagesBase64, setImagesBase64] = useState([]);
  const [hasMoreImages, setHasMoreImages] = useState(true);
  const [comments, setComments] = useState([]);
  const pageBook = useRef(0);
  const pageComment = useRef(0);
  const { token } = useAuth();
  const { bookId } = useParams();
  const fetchImages = () => {
    pageBook.current += 1;
    console.log(token, bookId);
    axios
      .get(
        "http://localhost:8098/file/readFileToImagePages?bookId=" +
          bookId +
          "&page=" +
          pageBook.current,
        {
          headers: {
            Authorization: "Bearer" + token,
          },
        }
      )
      .then((res) => {
        console.log(res.data.data.map((img) => Object.values(img)[0]));
        const newData = res.data.data.map((img) => Object.values(img)[0]);
        if (newData.length == 0) setHasMoreImages(false);
        setImagesBase64([...imagesBase64, ...newData]);
      })
      .catch(() => {
        toast.error("Couldn't load data. Please try again!");
      });
  };
  useEffect(fetchImages, [bookId, token]);
  useEffect(() => {
    const handleScroll = () => {
      if (!showHeaderFooter) return;
      //  console.log("Toggling Header/Footer...");
      setShowHeaderFooter(false);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleHeaderFooter = () => {
    setShowHeaderFooter(!showHeaderFooter);
  };
  return (
    <div className="read-book-ctn">
      <div
        className={`read-header  ${!showHeaderFooter ? "header-hidden" : ""}`}
      >
        <img src="/images/logo.png" alt="logo" id="logo" />
        <h2>Tên sách</h2>
        <div className="rating">
          <p>Đánh giá:</p>
          <RateBook isReadOnly={false} />
          <Tooltip title="Thêm vào danh sách yêu thích" arrow>
            <img src="/liked-icon.png" alt="like icon" />
          </Tooltip>
        </div>
      </div>
      <div className="book-content" onClick={toggleHeaderFooter}>
        <InfiniteScroll
          dataLength={imagesBase64.length} //This is important field to render the next data
          next={fetchImages}
          hasMore={hasMoreImages}
          loader={<h4>Loading...</h4>}
          endMessage={
            <p style={{ textAlign: "center" }}>
              <b>Yay! You have seen it all</b>
            </p>
          }
          // below props only if you need pull down functionality
          // refreshFunction={this.refresh}
          // pullDownToRefresh
          // pullDownToRefreshThreshold={50}
          // pullDownToRefreshContent={
          //   <h3 style={{ textAlign: "center" }}>
          //     &#8595; Pull down to refresh
          //   </h3>
          // }
          // releaseToRefreshContent={
          //   <h3 style={{ textAlign: "center" }}>&#8593; Release to refresh</h3>
          // }
          className="infinite-img"
        >
          {imagesBase64.map((img, index) => (
            <>
              <img
                key={index}
                // src={"data:image/png;base64," + img}
                alt=""
                style={{
                  backgroundImage: ` url("data:image/png;base64,${img}"`,
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "cover",
                  minWidth: "794px",
                  height: "1123px",
                }}
                id={`bg-img-${index}`}
              />
            </>
          ))}
        </InfiniteScroll>
      </div>
      <div
        className={`read-footer  ${!showHeaderFooter ? "footer-hidden" : ""}`}
      >
        <div>
          <img src="/comments.png" alt="comment-icon" />
        </div>
      </div>
      .
    </div>
  );
};

export default ReadBook;
